package com.example.puranjay.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.ToggleButton;

public class StopwatchActivity extends AppCompatActivity {
    private boolean firstTime = true;
    private long init,now,time,prev;
    private boolean on;
    private boolean running = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stopwatch);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ToggleButton resume = (ToggleButton)findViewById(R.id.start_button);
        TextView t = (TextView) findViewById(R.id.time_view);
        t.setText("00:00:00");
        if(savedInstanceState!=null)
        {
            running = savedInstanceState.getBoolean("running");
            init = savedInstanceState.getLong("seconds");
            on      = savedInstanceState.getBoolean("start");
            if(on){
                    resume.setChecked(true);
            }
        }
        //runTimer();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_stopwatch, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onClickStart(View view)
    {
        on = ((ToggleButton)view).isChecked();
        if(on) {
            running = true ;
            if(!firstTime){
                init+= (System.currentTimeMillis()-prev);
            }
            if (firstTime)
            {
                init = System.currentTimeMillis();
            }

            runTimer();
        }
         else{
            firstTime = false;
            running = false;
            prev = now;
        }

    }


    public void onClickReset(View view)
    {
        running = false;
        firstTime = true;
        time = 0;
        init = 0;
        now =  0;
        TextView t = (TextView) findViewById(R.id.time_view);
        t.setText("00:00:00");
        ToggleButton start = (ToggleButton)findViewById(R.id.start_button);
        start.setChecked(false);
    }
    //Sets the number of seconds on the timer.
    private void runTimer() {
        final TextView timeView = (TextView)findViewById(R.id.time_view);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                if(running){
                now = System.currentTimeMillis();
                time = now - init;
                String timing = String.format("%02d:%02d:%02d",((time/1000) % 3600) / 60,(time/1000) % 60, (time/10)%100);

                    timeView.setText(timing);
                handler.postDelayed(this, 30);
                }
            }
        });
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState)
    {
        savedInstanceState.putLong("milliseconds", init);
        savedInstanceState.putBoolean("running",running);
        savedInstanceState.putBoolean("start",on);
    }
}

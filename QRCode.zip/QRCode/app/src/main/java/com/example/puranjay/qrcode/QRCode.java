package com.example.puranjay.qrcode;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.oguzdev.circularfloatingactionmenu.library.FloatingActionButton;
import com.oguzdev.circularfloatingactionmenu.library.FloatingActionMenu;
import com.oguzdev.circularfloatingactionmenu.library.SubActionButton;

public class QRCode extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

       /* FloatingActionButton fab1 = (FloatingActionButton) findViewById(R.id.fab1);
        FloatingActionButton fab2 = (FloatingActionButton) findViewById(R.id.fab2);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        //FloatingActionButton.LayoutParams layoutParams1 = new FloatingActionButton.LayoutParams(500,500);

        ImageView imageView1= new ImageView(this);
        imageView1.setImageResource(R.drawable.quick_access);
        int height1 = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 100, getResources().getDisplayMetrics());
        int height2 = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, getResources().getDisplayMetrics());
        int radius = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 100, getResources().getDisplayMetrics());
        FloatingActionButton.LayoutParams layoutParams1 = new FloatingActionButton.LayoutParams(height1,height1);
        FloatingActionButton.Builder builder = new FloatingActionButton.Builder(this);
        builder.setContentView(imageView1);
        //builder.setBackgroundDrawable(R.drawable.selector_button_red);
        builder.setLayoutParams(layoutParams1);
        builder.setPosition(FloatingActionButton.POSITION_LEFT_CENTER);
        FloatingActionButton actionButton1 = builder.build();


        SubActionButton.Builder itemBuilder = new SubActionButton.Builder(this);

// repeat many times:
        ImageView itemIcon1 = new ImageView(this);
        itemIcon1.setImageResource(R.drawable.family);

        ImageView itemIcon2 = new ImageView(this);
        itemIcon2.setImageResource(R.drawable.work);

        ImageView itemIcon3 = new ImageView(this);
        itemIcon3.setImageResource(R.drawable.money);

        ImageView itemIcon4 = new ImageView(this);
        itemIcon4.setImageResource(R.drawable.quick_access);

        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(height2,height2);

        SubActionButton button1 = itemBuilder.setContentView(itemIcon1).setLayoutParams(layoutParams3).build();
        SubActionButton button2 = itemBuilder.setContentView(itemIcon2).build();
        SubActionButton button3 = itemBuilder.setContentView(itemIcon3).build();
        SubActionButton button4 = itemBuilder.setContentView(itemIcon4).build();

        FloatingActionMenu actionMenu1 = new FloatingActionMenu.Builder(this)
                .addSubActionView(button1)
                .addSubActionView(button2)
                .addSubActionView(button3)
                .addSubActionView(button4)

                .attachTo(actionButton1)

                .setStartAngle(-70)
                .setEndAngle(100)
                .setRadius(radius)
                .build();

        ImageView imageView2 = new ImageView(this);
        imageView2.setImageResource(R.drawable.quick_access);

        FloatingActionButton.LayoutParams layoutParams2 = new FloatingActionButton.LayoutParams(height1,height1);

        FloatingActionButton actionButton2 = new FloatingActionButton.Builder(this)
                .setContentView(imageView2)
                .setLayoutParams(layoutParams2)
                .setPosition(FloatingActionButton.POSITION_RIGHT_CENTER)
                .build();

        ImageView itemIcon5 = new ImageView(this);
        itemIcon5.setImageResource(R.drawable.family);

        ImageView itemIcon6 = new ImageView(this);
        itemIcon6.setImageResource(R.drawable.work);

        ImageView itemIcon7 = new ImageView(this);
        itemIcon7.setImageResource(R.drawable.money);

        ImageView itemIcon8 = new ImageView(this);
        itemIcon8.setImageResource(R.drawable.quick_access);

        FrameLayout.LayoutParams layoutParams4 = new FrameLayout.LayoutParams(height2,height2);

        SubActionButton button5 = itemBuilder.setContentView(itemIcon5).setLayoutParams(layoutParams4).build();
        SubActionButton button6 = itemBuilder.setContentView(itemIcon6).setLayoutParams(layoutParams4).build();
        SubActionButton button7 = itemBuilder.setContentView(itemIcon7).setLayoutParams(layoutParams4).build();
        SubActionButton button8 = itemBuilder.setContentView(itemIcon8).setLayoutParams(layoutParams4).build();

        FloatingActionMenu actionMenu2 = new FloatingActionMenu.Builder(this)
                .addSubActionView(button5)
                .addSubActionView(button6)
                .addSubActionView(button7)
                .addSubActionView(button8)
                .attachTo(actionButton2)
                .setStartAngle(-110)
                .setEndAngle(-280)
                .setRadius(radius)
                .build();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_qrcode, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}

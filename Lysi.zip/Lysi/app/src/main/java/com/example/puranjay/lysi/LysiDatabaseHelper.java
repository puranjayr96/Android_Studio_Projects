package com.example.puranjay.lysi;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Puranjay on 10/11/2015.
 */
 class LysiDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "lysi";
    private static final int DB_VERSION = 1;

    LysiDatabaseHelper(Context context) {
        super(context,DB_NAME,null,DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE DRINK("
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "NAME TEXT,"
                + "DESCRIPTION TEXT, "
                + "IMAGE_RESOURCE_ID INTEGER);");
        db.execSQL("ALTER TABLE DRINK ADD FAVORITE NUMERIC;");
        insertDrink(db, "Latte", "Espresso and steamed milk", R.drawable.coin,1);
        insertDrink(db,"Cappuccino","Espresso, hot milk and steamed-milk foam",R.drawable.coin,0);
        insertDrink(db,"Filter","Our best drip coffee",R.drawable.coin,0);

    }

    private static void insertDrink(SQLiteDatabase db, String name, String description, int resourceId,int favorite) {
        ContentValues drinkValues = new ContentValues();
        drinkValues.put("NAME",name);
        drinkValues.put("DESCRIPTION",description);
        drinkValues.put("IMAGE_RESOURCE_ID",resourceId);
        drinkValues.put("FAVORITE",favorite);
        db.insert("DRINK",null,drinkValues);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,int newVersion){

    }
}
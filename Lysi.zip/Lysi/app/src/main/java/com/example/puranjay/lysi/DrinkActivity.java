package com.example.puranjay.lysi;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DrinkActivity extends AppCompatActivity {
    public static String EXTRA_DRINKNO = "drinkNo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);
        //Get the drink from the intent
        int drinkNo = (Integer)getIntent().getExtras().get(EXTRA_DRINKNO);
/*        Drink drink = Drink.drinks[drinkNo];
//Populate the drink image
        ImageView photo = (ImageView)findViewById(R.id.coin);
        photo.setImageResource(drink.getImageResourceId());
        photo.setContentDescription(drink.getName());
//Populate the drink name
        TextView name = (TextView)findViewById(R.id.name);
        name.setText(drink.getName());
//Populate the drink description
        TextView description = (TextView)findViewById(R.id.description);
        description.setText(drink.getDescription());*/
        try {
            SQLiteOpenHelper lysiDatabaseHelper = new LysiDatabaseHelper(this);
            SQLiteDatabase db = lysiDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query("DRINK",new String[]{"NAME","DESCRIPTION","IMAGE_RESOURCE_ID","FAVORITE"},"_id = ?",new String[]{Integer.toString(drinkNo)},null,null,null);
            //Move the cursor to the first line
            if(cursor.moveToFirst()) {
                //Get the drink details
                String nameText = cursor.getString(0);
                String descriptionText = cursor.getString(1);
                int photoId = cursor.getInt(2);
                boolean isFavorite = (cursor.getInt(3) == 1);
                //Populate the views
                ImageView photo = (ImageView) findViewById(R.id.coin);
                photo.setImageResource(photoId);
                photo.setContentDescription(nameText);
                //Populate the drink name
                TextView name = (TextView) findViewById(R.id.name);
                name.setText(nameText);
                //Populate the drink description
                TextView description = (TextView) findViewById(R.id.description);
                description.setText(descriptionText);
                //Populate the favorite checkbox
                CheckBox favorite = (CheckBox)findViewById(R.id.favorite);
                favorite.setChecked(isFavorite);
            }
            cursor.close();
            db.close();

        }catch (SQLiteException e){
            Toast.makeText(DrinkActivity.this, "Database Unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_drink, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onFavoriteClicked(View view) {
        int drinkNo =(Integer)getIntent().getExtras().get(EXTRA_DRINKNO);
        new UpdateDrinkTask().execute(drinkNo);
       /* CheckBox favorite = (CheckBox)findViewById(R.id.favorite);
        ContentValues drinkValues = new ContentValues();
        drinkValues.put("FAVORITE",favorite.isChecked());
        SQLiteOpenHelper lysiDatabaseHelper = new LysiDatabaseHelper(DrinkActivity.this);
        try{
            SQLiteDatabase db = lysiDatabaseHelper.getWritableDatabase();
            db.update("DRINK",drinkValues,"_id=?",new String[]{Integer.toString(drinkNo)});
            db.close();
        }
        catch (Exception e)
        {
            Toast.makeText(this,"Database not available",Toast.LENGTH_LONG).show();
        }*/
    }

    //Inner class to update the drink
    private class UpdateDrinkTask extends AsyncTask<Integer,Void,Boolean>{
        ContentValues drinkValues;
        protected void onPreExecute(){
            CheckBox favorite = (CheckBox)findViewById(R.id.favorite);
            drinkValues = new ContentValues();
            drinkValues.put("FAVORITE",favorite.isChecked());
        }
        @Override
        protected Boolean doInBackground(Integer... drinks) {
            int drinkNo = drinks[0];
            SQLiteOpenHelper lysiDatabaseHelper = new LysiDatabaseHelper(DrinkActivity.this);
            try{
                SQLiteDatabase db = lysiDatabaseHelper.getWritableDatabase();
                db.update("DRINK",drinkValues,"_id = ?",new String[]{Integer.toString(drinkNo)});
                db.close();
                return true;
            }catch (Exception e){
                Toast.makeText(DrinkActivity.this,"Database Unavailable",Toast.LENGTH_LONG).show();
                return false;
            }

        }
        protected void onPostExecute(Boolean success){
            if(!success){
                Toast.makeText(DrinkActivity.this,"Database Unavailable",Toast.LENGTH_LONG).show();
            }
        }
    }

}

package com.example.puranjay.beeradviser;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import static java.lang.String.valueOf;

public class FindBeer extends AppCompatActivity
{

    private BeerMaster expert = new BeerMaster();
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_beer);
    }


    public void onClickFindBeer(View view)
    {   Toast.makeText(getApplicationContext(), "this is my Toast message!!! =)", Toast.LENGTH_SHORT).show();
        TextView brands = (TextView) findViewById(R.id.brands);//Fetching text field
        Spinner color = (Spinner) findViewById(R.id.color);//Fetching the dropdown menu
        String beerType = String.valueOf(color.getSelectedItem());//Get selected items from Drop Down menu
        List<String> brandslist = expert.getbeer(beerType);//Run expert class function to get beer list
        StringBuilder BeersFormatted = new StringBuilder();//string builder for a formatted display
        for (String beer : brandslist)//From 0 to the last element
        {
            BeersFormatted.append(beer).append("\n");
        }
        brands.setText(BeersFormatted);//set text as received info
    }
}

package com.example.puranjay.beeradviser;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Puranjay on 9/10/2015.
 */
public class BeerMaster
{
    List<String> getbeer(String color)
    {
        List<String> brands = new ArrayList<String>();
        if (color.equals("Light"))
        {
            brands.add("Jack Amber");
            brands.add("Red Moose");
        }
        else
        {
            brands.add("Jail Pail Ail");
            brands.add("desi Tharra");
        }
        return brands;
    }
}

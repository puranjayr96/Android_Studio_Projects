package com.example.puranjay.workout;

import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity implements WorkoutListFragment.WorkoutListListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WorkoutDetailFragment defaultin = new WorkoutDetailFragment();
        View fragmentdefault = findViewById(R.id.fragment_container);
        if(fragmentdefault!=null) {
            defaultin.setWorkoutId(0);
            FragmentTransaction df = getFragmentManager().beginTransaction();
            df.add(R.id.fragment_container, defaultin);
            df.addToBackStack(null);
            df.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            df.commit();
        }
    }

    @Override
    public void itemClicked(long id) {
        View fragmentcontainer = findViewById(R.id.fragment_container);
        if (fragmentcontainer != null) {
            WorkoutDetailFragment details = new WorkoutDetailFragment();
            FragmentTransaction ft = getFragmentManager().beginTransaction();
            details.setWorkoutId(id);
            ft.replace(R.id.fragment_container, details);
            ft.addToBackStack(null);

            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.commit();
        } else {
            Intent intent = new Intent(this, DetailActivity.class);
            intent.putExtra(DetailActivity.EXTRA_WORKOUT_ID, (int) id);
            startActivity(intent);
        }
    }
}

package com.example.puranjay.gdg;

/**
 * Created by Puranjay on 9/16/2015.
 */

import android.app.Application;

import com.parse.Parse;

public class SampleApplication extends Application {
    public void onCreate(){
        super.onCreate();
        Parse.initialize(this, "6tRk1xytjmoDkunbUGYARLkBBOZ98EyxO3xIL8b9", "d1EgTjEmdTcmpFfcNqcg4c3Vx8hk5I8vvN6aHNAj");

    }
}
